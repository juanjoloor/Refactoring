/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataClump;

/**
 *
 * @author Juan Jose
 */
/* Aqui tenemos un DataClump pues la clase Vendedor realizar un doble trabajo por lo que es necesario crear una nueva clase para que maneje la contabilidad de las ventas
public class Vendedor {
    String name;
    String VentasRealizadas ;
    double totalVentas;
    
    public ventas Ventas() {
        return ventas;
    }
    */
public class Vendedor {
  String name;

   public Ventas Ventas() {
        return Ventas();
    }
  
}

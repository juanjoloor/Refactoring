/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FeatureEnvy;

/**
 *
 * @author Juan Jose
 */

// anteriormente teniamos solo una operacion de sumar en la clase OSumar pero luego fueron surgiendo nuevas 
// operaciones y los datos fueron exportados a otra clase que es la que llamara a la funcion pre existente por 
// lo cual lo mejor es mover el metodo de la anterior clase hacia la nueva. 
public class Operaciones {
     int a ;
     int b;
  
      public int sum(){
      return this.a + this.b;
  }   
       public int restar(){
      return this.a - this.b;
  }   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchStatements;

/**
 *
 * @author Juan Jose
 */
public class ToyotaCarros {
   double motor;
   double width;
   int capacidad;
/* Este metodo esta dividido en partes y se ejecuta de acuerdo al valor que le pasemos como parametro por lo que es mejor extraer
   las partes individuales y crear sus propios metodos.
   
  public void setCaracteristica(String name, int value) {
  if (name.equals("motor")) {
    motor = value;
    return;
  }
  if (name.equals("capacidad")) {
    capacidad = value;
    return;
  }
  }
*/
      
   public void setMotor(int value){
       motor = value;
   } 
    
  public void setCapacidad(int value){
       motor = value;
   }   
    
    
    
}

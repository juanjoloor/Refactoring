/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PrimitiveObsession;

/**
 *
 * @author Juan Jose
 */

/* Code smell que sera refactorizado creando subclases para cada carrera de fiec
public class CarreaFiec {
    String Electronica;
    String Computacion;
    String tipo ;
}
*/
public class CarreaFiec {
    
}


